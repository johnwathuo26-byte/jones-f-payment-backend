# Jones F Shipping & Logistics — payment backend starter

This is a safe deployment scaffold, **not a live M-PESA integration**.

## Included
- Express API server with HTTPS-ready hosting behind Render
- Security headers, restricted CORS, request-size limit and rate limiting
- Booking creation and status lookup (in-memory development store)
- STK Push and callback routes deliberately disabled until Equity/Jenga approves the merchant integration

## Important before production
1. Obtain written Equity/Jenga approval and the official UAT/API specification for your exact merchant account.
2. Confirm the merchant account/reference, settlement account and callback requirements with Equity.
3. Implement the provider adapter and callback verification from the official specification.
4. Replace the in-memory store with a persistent database.
5. Add authentication/authorization for business/admin endpoints, logging, monitoring and reconciliation.
6. Set `WEBSITE_ORIGIN` to your actual website origin in Render.
7. Keep all credentials in Render Environment settings. Never commit `.env`, API secrets, passkeys or tokens to GitHub.
8. Do not switch to live mode until UAT succeeds and Equity authorizes production.

## Local test
Requires Node.js 20+.
```bash
npm install
cp .env.example .env
npm run dev
```
Open `http://localhost:3000/health`.

## Deploy to Render
1. Push this project to a private GitHub repository.
2. In Render, choose New + → Web Service and connect the repository.
3. Render should detect `render.yaml`. Use `npm install` and `npm start` if asked.
4. Set `WEBSITE_ORIGIN` to the website's real HTTPS origin.
5. Deploy and open `/health` on the Render service URL.

The free Render service is for initial testing only; it may sleep when idle. Choose a suitable paid instance and persistent database before live customer payments.
