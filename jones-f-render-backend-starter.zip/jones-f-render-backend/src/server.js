import "dotenv/config";
import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import crypto from "node:crypto";

const app = express();
const port = Number(process.env.PORT || 3000);
const allowedOrigin = process.env.WEBSITE_ORIGIN || "";

app.disable("x-powered-by");
app.use(helmet());
app.use(cors({
  origin(origin, callback) {
    if (!origin || !allowedOrigin || origin === allowedOrigin) return callback(null, true);
    return callback(new Error("Origin not allowed"));
  }
}));
app.use(express.json({ limit: "20kb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 30 }));

// Temporary in-memory store for development only.
// Replace with a persistent database before accepting real bookings or payments.
const bookings = new Map();

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "Jones F payment backend", mode: process.env.PAYMENT_MODE || "test" });
});

app.post("/api/bookings", (req, res) => {
  const { senderName, senderPhone, recipientName, recipientPhone, pickup, destination, contents, weightKg } = req.body || {};
  if (![senderName, senderPhone, recipientName, recipientPhone, pickup, destination, contents].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ error: "Please provide all required booking details." });
  }
  const weight = Number(weightKg);
  if (!Number.isFinite(weight) || weight <= 0 || weight > 1000) {
    return res.status(400).json({ error: "Weight must be between 0 and 1000 kg." });
  }

  const bookingId = `JF-${crypto.randomUUID()}`;
  const booking = {
    bookingId, senderName, senderPhone, recipientName, recipientPhone,
    pickup, destination, contents, weightKg: weight,
    status: "BOOKED_PAYMENT_NOT_STARTED",
    createdAt: new Date().toISOString()
  };
  bookings.set(bookingId, booking);
  return res.status(201).json({ bookingId, status: booking.status });
});

app.post("/api/payments/stk-push", (_req, res) => {
  // Intentionally disabled until Equity/Jenga approves the merchant integration
  // and provides official UAT documentation and credentials.
  if (process.env.PAYMENT_PROVIDER_READY !== "true") {
    return res.status(503).json({
      error: "STK Push is not enabled yet.",
      nextStep: "Complete Equity/Jenga merchant approval and configure the approved UAT integration."
    });
  }
  return res.status(501).json({
    error: "Provider adapter not installed.",
    nextStep: "Implement this route against the exact approved Equity/Jenga API specification."
  });
});

app.post("/api/payments/provider-callback", (_req, res) => {
  // Do not mark a payment PAID here until callback signature/authenticity,
  // merchant reference, amount, currency, and transaction status are verified.
  // Implement only from the provider's official callback specification.
  return res.status(501).json({ error: "Callback verification is not configured." });
});

app.get("/api/bookings/:bookingId", (req, res) => {
  const booking = bookings.get(req.params.bookingId);
  if (!booking) return res.status(404).json({ error: "Booking not found." });
  return res.json({
    bookingId: booking.bookingId,
    status: booking.status,
    createdAt: booking.createdAt
  });
});

app.listen(port, () => {
  console.log(`Jones F backend listening on port ${port}`);
});
